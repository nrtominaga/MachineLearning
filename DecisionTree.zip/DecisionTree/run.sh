python3 experiment.py
